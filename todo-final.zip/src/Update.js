import React, { useEffect, useState } from "react";
import { useHistory, useParams } from "react-router-dom";
import useFetch from "./useFetch";

function Update() {
    const history =useHistory();
    const { id } = useParams();   
    const  {data}  = useFetch("http://localhost:8000/blogs/" + id)    
    const [title, setTitle] = useState('');
    const [body, setBody] = useState('');
    useEffect(()=>{
        if(data){
        setBody(data.body);
        setTitle(data.title);
        }
        console.log(data)
    },[data])
  
   
    
    
    const handleSubmit=(e)=>{
        e.preventDefault();
        data.title=title;
        data.body=body;
        fetch("http://localhost:8000/blogs/" + data.id, {
          method: "PUT",
          headers: { 
            "Accept":"application/JSON",
            "content-type": "application/json" },
          body: JSON.stringify(data),
        }).then(() => {
            history.push(`/blogs/${id}`);          
        });        
    }
    
    console.log()
    return (
      <div >
        
        <div className="create">
      <h2>Update Blog</h2>
      <form onSubmit={handleSubmit}>
      {data&&<div>
        <label>Blog title:</label>
        <input
          type="text"
          required
          //placeholder={data.title}
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <label>Blog body:</label>
        <textarea
          required
          //placeholder={data.body}
          value={body}
          onChange={(e) => setBody(e.target.value)}
        ></textarea>      
        <button >Update</button>
        </div>}</form>
    </div>
    
        
      </div>
    );
}

export default Update
