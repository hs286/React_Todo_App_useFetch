import React, { useState } from "react";
import { Link, useHistory, useParams } from "react-router-dom";
import useFetch from "./useFetch";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";

function BlogDetails() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true, console.log(show));
  const history = useHistory();
  const { id } = useParams();
  const { data, loading, err } = useFetch("http://localhost:8000/blogs/" + id);
  const handleClick = () => {
    fetch("http://localhost:8000/blogs/" + data.id, {
      method: "DELETE",
    }).then(() => {
      history.push("/");
    });
  };

  const handleComplete = () => {
    data.complete = !data.complete;
    fetch("http://localhost:8000/blogs/" + data.id, {
      method: "PUT",
      headers: {
        Accept: "application/JSON",
        "content-type": "application/json",
      },
      body: JSON.stringify(data),
    }).then(() => {
      history.push("/blogs/" + data.id);
    });
  };
  const modal = () => {
    handleClose();
    handleClick();
  };
  return (
    <div className="blog-details">
      <Modal
        className="create"
        show={show}
        onHide={handleClose}
        animation={true}
      >
        <Modal.Body>Are u Sure u want to delete</Modal.Body>

        <Button onClick={handleClose}>No</Button>
        <Button onClick={modal}>Yes</Button>
      </Modal>
      {loading && <div>Loading...</div>}
      {err && <div>{err}</div>}
      {data && (
        <div>
          {show === false ? (
            <>
              <p>Title: {data.title}</p>
              <p>Description: {data.body}</p>
              <button onClick={handleShow}>delete</button>
              {data.complete ? (
                <button onClick={handleComplete}>In Complete</button>
              ) : (
                <button onClick={handleComplete}>Completed</button>
              )}
              {data.complete ? (
                <Link to={`/update/${data.id}`}>
                  <button>edit</button>
                </Link>
              ) : null}
            </>
          ) : null}
        </div>
      )}
    </div>
  );
}

export default BlogDetails;
