import { useState } from "react";
import { useHistory } from "react-router-dom";

const Create = () => {
  const history = useHistory();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  
  const [loading, setLoading] = useState(false);
  const complete = true;
  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    const blog = { title, body, complete };
    fetch("http://localhost:8000/blogs", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(blog),
    }).then(() => {
      console.log("new blog");
      setLoading(false);
      history.push("/");
    });
    
    setBody("");
    setTitle("");
  };
  return (
    <div className="create">
      <h2>Add a New Blog</h2>
      <form onSubmit={handleSubmit}>
        <label>Blog title:</label>
        <input
          type="text"
          required
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <label>Blog body:</label>
        <textarea
          required
          value={body}
          onChange={(e) => setBody(e.target.value)}
        ></textarea>
        
        {!loading && <button>Add Blog</button>}
        {loading && <button disabled>Adding Blog..</button>}
      </form>
    </div>
  );
};

export default Create;
